package com.org.foodapp.bills;

import java.util.ArrayList;

import com.org.foodapp.dto.FoodItem;

public class Totalbill {
      public static double gettotalbill(ArrayList<FoodItem> a) {
    	  double total=0;
    	  for(FoodItem fi:a) {
  			total+=(Double)fi.getPrice();
  			
  		}
		return total;
    	  
      }
}
