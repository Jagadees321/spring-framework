package com.org.restapidemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestapidemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
