# Online-Cab-Booking-System
This application is an online cab booking system designed using java **Spring MVC Framework**, Hibernate, JDBC, Servlets, JSP, HTML and CSS. It can be used
to book cabs between an entered source and destination along with vehicle of our choice. It has all the basic facilities that are
required by an user to have a convenient and hassle free `online booking experience`. 

###License
This project is licensed under the terms of the Apache-2.0 license
