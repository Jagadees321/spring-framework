package com.springboot001.springtask;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringtaskApplicationTests {

	@Test
	void contextLoads() {
	}

}
