package com.springboot001.springtask;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringtaskApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringtaskApplication.class, args);
	}

}
